from random import randrange as rr, seed

seed(0XDEAD_0060)

FLAG = '-------------- REMOVED --------------'
FLAG = bytearray(FLAG, 'utf-8')

for _ in range(len(FLAG)):
    FLAG[_] &= (((rr(2) << 16) + 0xDEAD + (0X_49_4E_53_49_44_45 >> 50)) >> 16) + (- (1 << 0O7 - 0B10) + (1 << 0B111) | 0B1110100) ^ ((0B10101111 << 0 | (0X1 << 0O2) + (0O1 << 0B11)) & 0B10011010 >> 0)

print('Encrypted flag:', FLAG.decode())
